const envList = [{"envId":"gllzteam-2gkr286e4675f96f","alias":"gllzteam"}]
const isMac = false
module.exports = {
    envList,
    isMac
}